# MoFA Cast - Changelog

> All notable changes to MoFA Cast project.

**Format**: This changelog follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) format.

---

## [0.5.0] - 2026-01-14

### ✅ Added - P1.1 Multi-Voice Support

**Core Feature**: Dynamic voice routing for different speakers

- **Smart Voice Assignment**: Automatic role-based voice mapping
  - host → Luo Xiang (deep male voice)
  - guest1 → Ma Yun (energetic male voice)
  - guest2 → Ma Baoguo (characteristic voice)
  - Zero-configuration user experience

- **Custom Voice Router Node**: `dora-voice-router`
  - Python-based routing node
  - JSON-based segment format: `{"speaker": "...", "text": "...", "voice_name": "...", "speed": 1.0}`
  - Routes to 3 parallel PrimeSpeech TTS nodes

- **Speaker Normalization**: Auto-merges duplicate speaker names
  - Merges "[主持人]" and "host" variants
  - Applied during TTS sending (doesn't modify UI text)

- **Multi-Voice Dataflow**: `dataflow/multi-voice-batch-tts.yml`
  - 3 parallel TTS nodes with different voice models
  - Automatic audio merging
  - Complete logging from all nodes

**Files Created**:
- `node-hub/dora-voice-router/` - Custom routing node
  - `pyproject.toml` - Package configuration
  - `dora_voice_router/main.py` - Routing logic
  - `README.md` - Documentation

**Files Modified**:
- `src/dora_integration.rs` - VoiceConfig, VoiceMapping, smart assignment
- `src/lib.rs` - Export voice types
- `src/screen.rs` - Speaker normalization, voice mapping UI
- `mofa-dora-bridge/src/widgets/cast_controller.rs` - Multi-input event handling
- `dataflow/multi-voice-batch-tts.yml` - New dataflow

**Testing Results**:
- ✅ 10/10 segments generated with distinct voices
- ✅ 100% success rate
- ✅ ~4s per segment (no slowdown)

**Breaking Changes**: None

**Migration Notes**: None (backward compatible)

---

### ✅ Added - P1.2 UI Enhancements (Partial)

**Core Feature**: Real-time log viewer and UI polish

- **Real-Time Log Viewer**:
  - Collapsible log panel (320px width, toggle button)
  - Log level filtering (ALL/INFO/WARN/ERROR)
  - Clear logs button
  - Markdown rendering for formatted logs
  - Auto-capture of all Dora events

- **Layout Improvements**:
  - Left panel width: 300px → 200px (33% reduction)
  - Compact spacing: ~28px vertical space saved
  - PanelHeader padding: 12px → 8px
  - CastScreen top padding: 16px → 12px

- **Visual Polish**:
  - Application icon: 🎙️ (studio microphone)
  - Custom dropdown styling with hover effects
  - Fixed color schemes for light theme
  - Text input auto-wrap and scrolling

**Files Modified**:
- `src/screen.rs` - Major UI updates
  - Added log_section UI (lines 448-596)
  - Fixed dropdown styles (format_dropdown, level_filter)
  - Improved text inputs (original_text, refined_text)
  - Added icon_label (header)
  - Reduced left panel width
  - Compact spacing

**State Added**:
- `log_entries: Vec<String>` - Log storage
- `log_level_filter: u32` - Filter level
- `log_panel_collapsed: bool` - Panel state
- `log_panel_width: f64` - Panel width

**Methods Added**:
- `ensure_log_initialized()` - Lazy initialization
- `toggle_log_panel()` - Show/hide panel
- `update_log_display()` - Filter and render
- `add_log()` - Add log entry
- `clear_logs()` - Reset logs

**Bugs Fixed**:
1. **Stack Overflow** - Fixed infinite recursion in initialization
2. **Scroll Component** - Changed from `Scroll` to `ScrollYView`
3. **White Text** - Fixed log text color (white → GRAY_700)

**Breaking Changes**: None

**Migration Notes**: None

---

### ⏳ Changed - TTS Engine Migration

**From**: Kokoro-82M (single voice)
**To**: PrimeSpeech (multi-voice)

**Reason**:
- Multi-voice support requirement (P1.1)
- Better Chinese TTS quality
- Multiple voice models available

**Impact**:
- ✅ Support for 3+ distinct voices
- ✅ Better Chinese pronunciation
- ✅ More voice options
- ⚠️ Single-voice mode still supported

**Files Deprecated**:
- `docs/KOKORO_TTS_GUIDE.md` → `docs/KOKORO_TTS_GUIDE_DEPRECATED.md`

**Dataflow Changes**:
- Old: `dataflow/batch-tts.yml` (Kokoro)
- New: `dataflow/multi-voice-batch-tts.yml` (PrimeSpeech × 3)

**Compatibility**: Fully backward compatible with single-voice mode

---

## [0.4.0] - 2026-01-14

### ✅ Added - P1.1 Multi-Voice Support

**See version 0.5.0 for full details**

---

## [0.3.0] - 2026-01-09

### ✅ Added - P0.6 Dora Integration

**Core Feature**: 100% reliable sequential TTS sending

- **DoraProcessManager**: Auto-start daemon/coordinator
- **Event Forwarding**: Fixed segment_complete propagation
- **Sequential Processing**: Flow control with segment_complete handshake
- **Test Results**: 10/10 segments generated (100% success rate)

**Critical Fix**:
```rust
// Before (BROKEN - only 1 segment):
"segment_complete" => {
    // No event sent!
}

// After (WORKING - all segments):
"segment_complete" => {
    let _ = event_sender.send(BridgeEvent::DataReceived {
        input_id: "segment_complete".to_string(),
        data: DoraData::Empty,
        metadata: event_meta,
    });
}
```

**Performance**:
- ⚠️ Slower (40s for 10 segments vs 10s with batch)
- ✅ But 100% reliable (batch only 20% reliable)
- ✅ Predictable processing time
- ✅ Better progress tracking

---

### ✅ Added - P0.5 Audio Mixing and Export

**Features**:
- Audio segment concatenation
- Silence between segments (0.5s default)
- WAV file export
- Volume normalization interface
- Metadata support structure

**Testing**: 5 unit tests, all passing

---

## [0.2.0] - 2026-01-08

### ✅ Added - P0.3 AI Script Refinement

**Features**:
- OpenAI API integration (GPT-4)
- Mock refiner for testing without API
- Streaming responses
- Prompt templates for structured outputs
- Comprehensive error handling (8 error types)

**Testing**: 2 unit tests, all passing

---

## [0.1.0] - 2026-01-08

### ✅ Added - P0.1 Transcript Parsing

**Features**:
- Plain text parser (speaker: message format)
- JSON parser (OpenAI chat format)
- Markdown parser (GitHub discussions)
- Auto-detection with ParserFactory
- Speaker statistics extraction
- Unit tests (5/5 passing)

**Files**: `transcript_parser.rs` (~672 lines)

---

### ✅ Added - P0.2 Script Editor UI

**Features**:
- Split-view layout (original | refined)
- File import with format detection
- Dark mode support
- Shell integration with sidebar
- Speaker statistics display

**Files**: `screen.rs` (~590 lines)

---

## [0.0.1] - 2026-01-07

### ✅ Added - Project Initialization

**Features**:
- Project structure created
- Dependencies configured (Cargo.toml)
- MofaApp trait implemented
- Documentation organized
- MoFA Studio shell integration

---

## Version Summary

| Version | Date | Status | Key Features |
|---------|------|--------|--------------|
| 0.5.0 | 2026-01-14 | ✅ Stable | Multi-voice support, UI enhancements |
| 0.4.0 | 2026-01-14 | ✅ Stable | Dora integration, sequential sending |
| 0.3.0 | 2026-01-09 | ✅ Stable | Audio mixing and WAV export |
| 0.2.0 | 2026-01-08 | ✅ Stable | AI script refinement |
| 0.1.0 | 2026-01-08 | ✅ Stable | Transcript parsing and UI |
| 0.0.1 | 2026-01-07 | ✅ Alpha | Project initialization |

---

## Migration Guide

### Upgrading from 0.3.x to 0.5.0

**No breaking changes** - All existing scripts and dataflows work.

**New Features Available**:
1. Multi-voice support: Use `multi-voice-batch-tts.yml` instead of `batch-tts.yml`
2. Log viewer: Automatically enabled in UI
3. Compact layout: Left panel now 200px (was 300px)

**Recommended Actions**:
- Update dataflow path to use `multi-voice-batch-tts.yml`
- Configure voice mapping in UI (automatic for common patterns)
- Use log panel for debugging and progress tracking

---

## Deprecations

### Deprecated in 0.5.0

- **Kokoro TTS Engine**: Replaced by PrimeSpeech for multi-voice support
  - Reason: PrimeSpeech supports multiple voice models
  - Migration: Update dataflow to use PrimeSpeech nodes
  - Documentation: See `docs/KOKORO_TTS_GUIDE_DEPRECATED.md`

### Removed Features

None - All features from 0.3.x are still supported in 0.5.0

---

## Future Roadmap

### Planned for v0.6.0

- **MP3 Export**: Bitrate selection (128k/192k/320k)
- **Audio Player Widget**: In-app playback
- **Keyboard Shortcuts**: Ctrl+O (open), Ctrl+S (save), Ctrl+E (export)
- **Auto-Save**: Prevent data loss

### Planned for v0.7.0

- **Advanced Format Support**: WhatsApp, WeChat, Telegram, Discord
- **Audio Enhancements**: Volume normalization, crossfade
- **Progress Tracking**: ETA calculation, per-segment progress bars
