//! Script Refiner - AI-powered transcript to podcast script conversion
//!
//! This module provides AI script refinement using OpenAI or Claude API:
//! - Transcript to podcast script conversion
//! - Streaming response support
//! - Error handling and retry logic
//! - API key management

use crate::transcript_parser::Transcript;
use async_trait::async_trait;
use chrono::{DateTime, Utc};
use reqwest::{Client, StatusCode};
use serde::{Deserialize, Serialize};
use std::time::Duration;

// ============================================================================
// DATA MODELS
// ============================================================================

/// AI provider options
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AiProvider {
    OpenAI,
    Claude,
}

/// Refinement configuration
#[derive(Debug, Clone)]
pub struct RefinementConfig {
    pub provider: AiProvider,
    pub api_key: String,
    pub model: String,
    pub max_tokens: Option<u32>,
    pub temperature: f32,
}

impl Default for RefinementConfig {
    fn default() -> Self {
        Self {
            provider: AiProvider::OpenAI,
            api_key: String::new(),
            model: "gpt-4".to_string(),
            max_tokens: Some(4000),
            temperature: 0.7,
        }
    }
}

/// Refinement request
#[derive(Debug, Clone)]
pub struct RefinementRequest {
    pub transcript: Transcript,
    pub config: RefinementConfig,
}

/// Refinement result
#[derive(Debug, Clone)]
pub struct RefinementResult {
    pub refined_script: String,
    pub model_used: String,
    pub tokens_used: Option<u32>,
    pub duration_ms: u64,
}

/// Progress callback for streaming
pub type ProgressCallback = Box<dyn Fn(String) + Send + Sync>;

// ============================================================================
// TRAIT DEFINITIONS
// ============================================================================

/// AI script refiner trait
#[async_trait]
pub trait ScriptRefiner: Send + Sync {
    /// Refine transcript into podcast script
    async fn refine(&self, request: RefinementRequest) -> Result<RefinementResult, RefinerError>;

    /// Refine with streaming progress updates
    async fn refine_stream(
        &self,
        request: RefinementRequest,
        progress: ProgressCallback,
    ) -> Result<RefinementResult, RefinerError>;
}

/// Errors that can occur during refinement
#[derive(Debug, Clone)]
pub enum RefinerError {
    MissingApiKey,
    InvalidApiKey,
    ApiError(String),
    RateLimitExceeded,
    Timeout,
    NetworkError(String),
    InvalidResponse(String),
    Other(String),
}

impl std::fmt::Display for RefinerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            RefinerError::MissingApiKey => write!(f, "API key is missing"),
            RefinerError::InvalidApiKey => write!(f, "Invalid API key"),
            RefinerError::ApiError(msg) => write!(f, "API error: {}", msg),
            RefinerError::RateLimitExceeded => write!(f, "Rate limit exceeded"),
            RefinerError::Timeout => write!(f, "Request timed out"),
            RefinerError::NetworkError(msg) => write!(f, "Network error: {}", msg),
            RefinerError::InvalidResponse(msg) => write!(f, "Invalid response: {}", msg),
            RefinerError::Other(msg) => write!(f, "Error: {}", msg),
        }
    }
}

impl std::error::Error for RefinerError {}

// ============================================================================
// PROMPT TEMPLATES
// ============================================================================

pub struct PromptTemplates;

impl PromptTemplates {
    /// Get the main refinement prompt
    pub fn get_refinement_prompt(transcript: &Transcript) -> String {
        let participants = &transcript.metadata.participants;
        let participant_list = participants.join(", ");

        format!(
            r#"You are an expert podcast scriptwriter. Transform the following chat transcript into an engaging podcast script.

TRANSCRIPT:
{}

PARTICIPANTS: {}

REQUIREMENTS:
1. Add an engaging introduction that hooks the listener
2. Smooth out awkward phrases and repetitions
3. Add natural transitions between topics
4. Include host commentary to guide the conversation
5. Maintain the original meaning and key points
6. Format for spoken delivery (punctuation, pauses, emphasis)
7. Keep the same participants: {}

OUTPUT FORMAT:
Use this format for each line:
[Speaker Name]: Dialogue here

Keep it conversational, engaging, and suitable for audio recording.

PRODUCE THE REFINED SCRIPT NOW:"#,
            Self::format_transcript_for_prompt(transcript),
            participant_list,
            participant_list
        )
    }

    /// Format transcript for the prompt
    fn format_transcript_for_prompt(transcript: &Transcript) -> String {
        transcript
            .messages
            .iter()
            .map(|msg| format!("{}: {}", msg.speaker, msg.text))
            .collect::<Vec<_>>()
            .join("\n")
    }

    /// Get system prompt
    pub fn get_system_prompt() -> &'static str {
        "You are a professional podcast scriptwriter with expertise in creating engaging audio content from conversational transcripts."
    }
}

// ============================================================================
// OPENAI CLIENT
// ============================================================================

pub struct OpenAiRefiner {
    client: Client,
    api_key: String,
    model: String,
    max_tokens: u32,
    temperature: f32,
}

impl OpenAiRefiner {
    pub fn new(config: &RefinementConfig) -> Result<Self, RefinerError> {
        if config.api_key.is_empty() {
            return Err(RefinerError::MissingApiKey);
        }

        let client = Client::builder()
            .timeout(Duration::from_secs(120))
            .build()
            .map_err(|e| RefinerError::Other(format!("Failed to create client: {}", e)))?;

        Ok(Self {
            client,
            api_key: config.api_key.clone(),
            model: config.model.clone(),
            max_tokens: config.max_tokens.unwrap_or(4000),
            temperature: config.temperature,
        })
    }
}

#[async_trait]
impl ScriptRefiner for OpenAiRefiner {
    async fn refine(&self, request: RefinementRequest) -> Result<RefinementResult, RefinerError> {
        // For now, use non-streaming version
        let progress = Box::new(|_text| ());
        self.refine_stream(request, progress).await
    }

    async fn refine_stream(
        &self,
        request: RefinementRequest,
        progress: ProgressCallback,
    ) -> Result<RefinementResult, RefinerError> {
        let start_time = std::time::Instant::now();

        // Build the request
        let system_prompt = PromptTemplates::get_system_prompt();
        let user_prompt = PromptTemplates::get_refinement_prompt(&request.transcript);

        let api_request = OpenAiRequest {
            model: self.model.clone(),
            messages: vec![
                ApiMessage {
                    role: "system".to_string(),
                    content: system_prompt.to_string(),
                },
                ApiMessage {
                    role: "user".to_string(),
                    content: user_prompt,
                },
            ],
            max_tokens: self.max_tokens,
            temperature: self.temperature,
            stream: false, // For simplicity, start with non-streaming
        };

        // Send request
        let response = self
            .client
            .post("https://api.openai.com/v1/chat/completions")
            .header("Authorization", format!("Bearer {}", self.api_key))
            .header("Content-Type", "application/json")
            .json(&api_request)
            .send()
            .await
            .map_err(|e| RefinerError::NetworkError(format!("Request failed: {}", e)))?;

        let status = response.status();

        if status == StatusCode::UNAUTHORIZED {
            return Err(RefinerError::InvalidApiKey);
        } else if status == StatusCode::TOO_MANY_REQUESTS {
            return Err(RefinerError::RateLimitExceeded);
        } else if !status.is_success() {
            let error_text = response
                .text()
                .await
                .unwrap_or_else(|_| "Unknown error".to_string());
            return Err(RefinerError::ApiError(error_text));
        }

        // Parse response
        let api_response: OpenAiResponse = response
            .json()
            .await
            .map_err(|e| RefinerError::InvalidResponse(format!("Failed to parse: {}", e)))?;

        if api_response.choices.is_empty() {
            return Err(RefinerError::InvalidResponse("No choices in response".to_string()));
        }

        let refined_script = api_response.choices[0].message.content.clone();
        let tokens_used = api_response.usage.total_tokens;

        // Call progress with final result
        progress(refined_script.clone());

        Ok(RefinementResult {
            refined_script,
            model_used: self.model.clone(),
            tokens_used: Some(tokens_used),
            duration_ms: start_time.elapsed().as_millis() as u64,
        })
    }
}

// ============================================================================
// OPENAI API TYPES
// ============================================================================

#[derive(Debug, Serialize)]
struct OpenAiRequest {
    model: String,
    messages: Vec<ApiMessage>,
    max_tokens: u32,
    temperature: f32,
    stream: bool,
}

#[derive(Debug, Serialize)]
struct ApiMessage {
    role: String,
    content: String,
}

#[derive(Debug, Deserialize)]
struct OpenAiResponse {
    choices: Vec<Choice>,
    usage: Usage,
}

#[derive(Debug, Deserialize)]
struct Choice {
    message: ApiMessageResponse,
    finish_reason: Option<String>,
}

#[derive(Debug, Deserialize)]
struct ApiMessageResponse {
    content: String,
}

#[derive(Debug, Deserialize)]
struct Usage {
    prompt_tokens: u32,
    completion_tokens: u32,
    total_tokens: u32,
}

// ============================================================================
// FACTORY
// ============================================================================

pub struct RefinerFactory;

impl RefinerFactory {
    pub fn create_refiner(config: &RefinementConfig) -> Result<Box<dyn ScriptRefiner>, RefinerError> {
        match config.provider {
            AiProvider::OpenAI => {
                let refiner = OpenAiRefiner::new(config)?;
                Ok(Box::new(refiner))
            }
            AiProvider::Claude => {
                // TODO: Implement Claude refiner
                Err(RefinerError::Other("Claude provider not yet implemented".to_string()))
            }
        }
    }
}

// ============================================================================
// MOCK REFINER (for testing without API)
// ============================================================================

pub struct MockRefiner;

#[async_trait]
impl ScriptRefiner for MockRefiner {
    async fn refine(&self, request: RefinementRequest) -> Result<RefinementResult, RefinerError> {
        // Simulate API delay
        tokio::time::sleep(Duration::from_millis(500)).await;

        // Generate a mock refined script
        let refined_script = Self::generate_mock_script(&request.transcript);

        Ok(RefinementResult {
            refined_script,
            model_used: "mock-model".to_string(),
            tokens_used: Some(500),
            duration_ms: 500,
        })
    }

    async fn refine_stream(
        &self,
        request: RefinementRequest,
        progress: ProgressCallback,
    ) -> Result<RefinementResult, RefinerError> {
        let result = self.refine(request).await?;
        progress(result.refined_script.clone());
        Ok(result)
    }
}

impl MockRefiner {
    fn generate_mock_script(transcript: &Transcript) -> String {
        let mut script = String::new();

        // Add intro
        if let Some(first_msg) = transcript.messages.first() {
            script.push_str(&format!(
                "[主持人]: 欢迎收听本期节目！今天我们聊一聊{}，有请{}。\n\n",
                "这个有趣的话题",
                first_msg.speaker
            ));
        }

        // Add refined dialogue
        for msg in &transcript.messages {
            script.push_str(&format!("{}: {}\n", msg.speaker, msg.text));
        }

        // Add outro
        script.push_str("\n[主持人]: 感谢收听！我们下期再见。");

        script
    }
}

// ============================================================================
// TESTS
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::transcript_parser::{Message as ParserMessage, Metadata, TranscriptFormat};

    #[test]
    fn test_prompt_generation() {
        let transcript = Transcript {
            messages: vec![
                ParserMessage {
                    speaker: "Alice".to_string(),
                    text: "Hello Bob".to_string(),
                    timestamp: None,
                },
                ParserMessage {
                    speaker: "Bob".to_string(),
                    text: "Hi Alice".to_string(),
                    timestamp: None,
                },
            ],
            metadata: Metadata {
                title: None,
                date: None,
                participants: vec!["Alice".to_string(), "Bob".to_string()],
                format: TranscriptFormat::PlainText,
            },
        };

        let prompt = PromptTemplates::get_refinement_prompt(&transcript);

        assert!(prompt.contains("Alice: Hello Bob"));
        assert!(prompt.contains("Bob: Hi Alice"));
        assert!(prompt.contains("PARTICIPANTS: Alice, Bob"));
    }

    #[tokio::test]
    async fn test_mock_refiner() {
        let refiner = MockRefiner;

        let transcript = Transcript {
            messages: vec![
                ParserMessage {
                    speaker: "Alice".to_string(),
                    text: "Test message".to_string(),
                    timestamp: None,
                },
            ],
            metadata: Metadata {
                title: None,
                date: None,
                participants: vec!["Alice".to_string()],
                format: TranscriptFormat::PlainText,
            },
        };

        let config = RefinementConfig::default();
        let request = RefinementRequest { transcript, config };

        let result = refiner.refine(request).await.unwrap();

        assert!(!result.refined_script.is_empty());
        assert_eq!(result.model_used, "mock-model");
        assert!(result.duration_ms >= 500);
    }
}
