# MoFA Cast - Architecture Guide

**Version**: 0.3.0 (P0 Complete - PrimeSpeech Integration)
**Status**: ✅ Production-Ready (TTS working with sequential sending)
**Framework**: Makepad GPU-accelerated UI + Dora Dataflow
**Pattern**: Content transformation app (Chat → Podcast)
**Last Updated**: 2026-01-14

---

## Project Overview

**MoFA Cast** transforms chat transcripts into polished podcast scripts with AI editing and TTS synthesis. Built as a MoFA Studio plugin, it demonstrates document processing and batch TTS synthesis with **100% reliable sequential processing**.

### Core Functionality

- ✅ UI Framework and shell integration
- ✅ Import chat transcripts (plain text, JSON, Markdown)
- ✅ AI script refinement (GPT-4, Claude support implemented)
- ✅ Multi-speaker script generation
- ✅ **Batch TTS synthesis with PrimeSpeech (all segments working)**
- ⏳ Audio mixing and export (MP3/WAV)
- ✅ Script editor with preview (UI complete)
- ⏳ Export to common podcast formats

---

## Directory Structure

```
apps/mofa-cast/
├── Cargo.toml                   # Dependencies ✅
├── README.md                    # Project overview ✅
├── dataflow/                    # Dora dataflow configs ✅
│   ├── batch-tts.yml            # Original TTS batch pipeline
│   └── test-primespeech-simple.yml  # Simplified PrimeSpeech config ✅
├── docs/                        # Documentation ✅
│   ├── ARCHITECTURE.md          # This file ✅
│   ├── ARCHITECTURE_cn.md       # 架构指南（中文）✅
│   ├── APP_DEVELOPMENT_GUIDE.md # Development tutorial ✅
│   ├── CHECKLIST.md             # Implementation checklist ✅
│   ├── roadmap-claude.md        # Development roadmap ✅
│   ├── TTS_INTEGRATION.md       # TTS engine technical decision ✅
│   ├── TTS_TROUBLESHOOTING.md   # TTS bugs and solutions ✅
│   ├── TTS_WORKFLOW_TEST.md     # TTS workflow testing guide ✅
│   ├── KOKORO_TTS_GUIDE.md      # Kokoro TTS guide (deprecated) ⚠️
│   └── TEST_REPORT_TEMPLATE.md  # Testing template ✅
└── src/
    ├── lib.rs                   # MofaApp trait implementation ✅
    ├── screen.rs                # Main UI screen ✅
    ├── transcript_parser.rs     # Parse various chat formats ✅
    ├── script_refiner.rs        # AI script generation ✅
    ├── tts_batch.rs             # TTS engine abstraction ✅
    ├── audio_mixer.rs           # Combine audio segments ⏳
    └── dora_integration.rs      # Dora dataflow integration ✅
```

**Legend**:
- ✅ Completed
- ⏳ Pending (planned)

---

## Technical Architecture

### 1. Input Processing Pipeline

```
Chat Transcript
    ↓ [parse format]
Structured Dialog
    ├─ Speaker 1: [messages]
    ├─ Speaker 2: [messages]
    └─ Metadata (time, topic)
    ↓ [AI refinement]
Podcast Script
    ├─ Introduction
    ├─ Main Content (refined)
    ├─ Transitions
    └─ Conclusion
```

**Supported Formats**:
- Plain text (speaker: message)
- JSON (OpenAI chat format)
- Markdown (GitHub discussions)
- WhatsApp export
- WeChat export

### 2. AI Script Refinement (✅ Implemented)

```yaml
Refinement Steps:
  1. Extract key points
  2. Add structure (intro/body/conclusion)
  3. Smooth transitions
  4. Add host commentary
  5. Format for TTS (punctuation, pauses)
```

**LLM Prompt Example**:
```
Transform this chat transcript into a podcast script:
- Add engaging introduction
- Rephrase awkward phrases
- Add host transitions
- Maintain conversational tone
- Format: [Speaker] dialog
```

**Implementation Details** (P0.3 Complete):

```rust
// Trait-based architecture for extensibility
#[async_trait]
pub trait ScriptRefiner: Send + Sync {
    async fn refine(&self, request: RefinementRequest)
        -> Result<RefinementResult, RefinerError>;
    async fn refine_stream(&self, request: RefinementRequest,
        progress: ProgressCallback) -> Result<RefinementResult, RefinerError>;
}

// Multiple AI providers supported
pub enum AiProvider {
    OpenAI,  // ✅ Implemented
    Claude,  // ✅ Stub (API integration ready)
}

// Error handling for production use
pub enum RefinerError {
    MissingApiKey,
    InvalidApiKey,
    ApiError(String),
    RateLimitExceeded,
    Timeout,
    NetworkError(String),
    InvalidResponse(String),
    Other(String),
}

// Testing without API costs
pub struct MockRefiner;  // ✅ Implemented for testing
```

**Key Features**:
- Async/await with tokio runtime integration
- Streaming support for real-time progress updates
- Comprehensive error handling (8 error types)
- Mock refiner for testing without API keys
- Structured prompt templates for consistent results
- Factory pattern for easy provider switching

### 3. TTS Synthesis Pipeline (✅ Dora Dataflow)

**Critical Architecture Decision** (2026-01-14):
- **Problem**: Batch sending overwhelmed TTS nodes (only 2/10 segments processed)
- **Solution**: Sequential sending with `segment_complete` handshake
- **Result**: 100% reliable (10/10 segments processed)
- **Details**: See `TTS_INTEGRATION.md` - "Critical Discovery: Batch vs Sequential Sending"

```
Script Segments
    ↓ [sequential send with flow control]
Dora Dataflow (test-primespeech-simple.yml)
    ├─ mofa-cast-controller (dynamic node)
    │   ├─ Send segment 1 → Wait for segment_complete
    │   ├─ Send segment 2 → Wait for segment_complete
    │   └─ Repeat until all segments sent
    ├─ primespeech-tts (dora-primespeech)
    │   ├─ Voice: Luo Xiang (Chinese)
    │   ├─ Language: zh (Chinese)
    │   ├─ Speed: 1.0x
    │   └─ Processing time: 2-4s per segment
    └─ mofa-cast-controller (dynamic node)
        └─ Send audio + segment_complete back to mofa-cast
    ↓ [async event processing]
Audio Segments (received via events)
    ├─ Progress updates (current/total)
    ├─ Individual audio chunks (WAV format)
    └─ Completion notification
    ↓ [concatenate + normalize] (TODO)
Final Podcast Audio (TODO)
```

**Dataflow Configuration** (`dataflow/test-primespeech-simple.yml`):

```yaml
nodes:
  # Direct connection - no text-segmenter needed
  - id: mofa-cast-controller
    path: dynamic
    inputs:
      audio: primespeech-tts/audio
      segment_complete: primespeech-tts/segment_complete
      log: primespeech-tts/log
    outputs:
      - text

  - id: primespeech-tts
    build: pip install -e ../../../libs/dora-common -e ../../../node-hub/dora-primespeech
    path: dora-primespeech
    inputs:
      text: mofa-cast-controller/text
    outputs:
      - audio
      - segment_complete
      - log
    env:
      TRANSFORMERS_OFFLINE: "1"
      HF_HUB_OFFLINE: "1"
      VOICE_NAME: "Luo Xiang"
      PRIMESPEECH_MODEL_DIR: $HOME/.dora/models/primespeech
      TEXT_LANG: zh
      PROMPT_LANG: zh
      TOP_K: 5
      TOP_P: 1.0
      TEMPERATURE: 1.0
      SPEED_FACTOR: 1.0
      ENABLE_INTERNAL_SEGMENTATION: "true"
      TTS_MAX_SEGMENT_LENGTH: "100"
      TTS_MIN_SEGMENT_LENGTH: "20"
      LOG_LEVEL: DEBUG
```

**Integration Architecture** (Sequential Sending):

```rust
// Dora integration layer (dora_integration.rs)
pub struct DoraState {
    pub pending_segments: Vec<ScriptSegment>,  // Queue for sequential sending
    pub current_segment_index: usize,           // Track progress
    pub total_segments: usize,                  // Total expected
}

// Worker thread manages dataflow lifecycle
fn worker_thread(...) {
    // ...
    SendScriptSegments { segments } => {
        // CRITICAL: Store all segments, send ONLY first
        state.write().pending_segments = segments.clone();
        state.write().current_segment_index = 0;
        state.write().total_segments = segments.len();

        // Send first segment
        bridge.send("text", DoraData::Text(segments[0].text))?;

        // Wait for segment_complete before sending next
    }

    // In poll_events loop:
    BridgeEvent::DataReceived { input_id: "segment_complete", .. } => {
        // Send NEXT segment only when current is complete
        let idx = state.read().current_segment_index;
        if idx + 1 < state.read().pending_segments.len() {
            let next = &state.read().pending_segments[idx + 1];
            bridge.send("text", DoraData::Text(next.text))?;
            state.write().current_segment_index = idx + 1;
        }
    }
}
```

**Why Sequential Sending Works**:
- ✅ **Flow control**: TTS node processes at its own pace
- ✅ **No queue overflow**: Only one segment in flight at a time
- ✅ **Reliable**: 100% segments processed (vs 20% with batch)
- ✅ **Matches real-time pattern**: Similar to mofa-fm voice chat
- ✅ **Event forwarding**: Bridge properly forwards segment_complete signals

**Critical Fix Required** (2026-01-14):
`cast_controller.rs` must forward `segment_complete` events:
```rust
// Before (BROKEN - only 1 segment):
"segment_complete" => {
    info!("Segment complete signal received");
    // ❌ No event sent!
}

// After (WORKING - all segments):
"segment_complete" => {
    info!("Segment complete signal received");
    let _ = event_sender.send(BridgeEvent::DataReceived {
        input_id: "segment_complete".to_string(),
        data: DoraData::Empty,
        metadata: event_meta,
    });
}
```

**Without this fix**: Sequential sending never triggers next segment → only 1 segment generated
**With this fix**: All 9-10 segments generated reliably

**Performance Trade-off**:
- ⚠️ Slower overall (40s for 10 segments vs 10s with batch)
- ✅ But 100% reliable (batch only 20% reliable)
- ✅ Predictable processing time
- ✅ Better progress tracking (know exactly which segment is processing)

**TTS Engine Support**:

- ✅ **PrimeSpeech (GPT-SoVITS)**: Local Chinese TTS engine (CURRENT)
  - Voice quality: Excellent for Chinese
  - Processing speed: 0.76x realtime (slower)
  - Multiple voices: Luo Xiang, Yang Mi, Ma Yun
  - **Status**: Production-ready, 100% reliable (all segments tested)
- ⚠️ **Kokoro-82M**: Local TTS engine (TESTED - REJECTED)
  - CPU backend bug: Only processes 2/10 segments
  - MLX backend: No audio output
  - **Status**: Unstable, not suitable for production
- ⏳ **MockTtsEngine**: Testing with simple tones

### 4. UI Components (✅ Implemented)

```
CastScreen (✅)
├── Header (✅)
│   ├── Title Label
│   └── Description
├── Main Content
│   ├── Left Panel (✅)
│   │   ├── Import Section (✅)
│   │   │   ├── Format Dropdown (✅)
│   │   │   ├── Import Button (✅)
│   │   │   └── File Info Label (✅)
│   │   └── Speakers Section (✅)
│   │       └── Speakers List Placeholder (✅)
│   └── Right Panel (✅)
│       ├── Control Bar (✅)
│       │   ├── Refine Button (✅)
│       │   ├── Synthesize Button (✅)
│       │   ├── Export Button (✅)
│       │   └── Progress Label (✅)
│       └── Editor Container (✅)
│           ├── Original Panel (✅)
│           │   ├── Panel Header (✅)
│           │   └── Original Text Input (✅)
│           └── Refined Panel (✅)
│               ├── Panel Header (✅)
│               └── Refined Text Input (✅)
```

**Implementation Notes**:
- All UI components use Makepad's `live_design!` macro
- Dark mode support via `instance dark_mode: 0.0`
- Integrated with MoFA Studio shell navigation
- Sidebar button with custom icon (`cast.svg`)

---

## Data Models

### Transcript

```rust
pub struct Transcript {
    pub messages: Vec<Message>,
    pub metadata: Metadata,
}

pub struct Message {
    pub speaker: String,
    pub text: String,
    pub timestamp: Option<DateTime<Utc>>,
}

pub struct Metadata {
    pub title: Option<String>,
    pub date: Option<DateTime<Utc>>,
    pub participants: Vec<String>,
}
```

### Podcast Script

```rust
pub struct PodcastScript {
    pub segments: Vec<Segment>,
    pub speakers: Vec<Speaker>,
    pub total_duration: Option<Duration>,
}

pub struct Segment {
    pub speaker_id: usize,
    pub text: String,
    pub audio_path: Option<PathBuf>,  // After TTS
}

pub struct Speaker {
    pub name: String,
    pub voice_id: String,  // TTS voice model
    pub color: Color,      // UI color coding
}
```

---

## Dora Integration

### Dataflow for Batch TTS

```yaml
nodes:
  - id: text-segmenter
    operator: python
    inputs: { script: stdin }
    outputs: [segments]

  - id: tts-speaker1
    operator: python (dora-primespeech)
    inputs: { text: text-segmenter/segments }
    outputs: [audio]
    env:
      VOICE_NAME: "Male_01"

  - id: tts-speaker2
    operator: python (dora-primespeech)
    inputs: { text: text-segmenter/segments }
    outputs: [audio]
    env:
      VOICE_NAME: "Female_01"

  - id: audio-mixer
    operator: python
    inputs:
      audio1: tts-speaker1/audio
      audio2: tts-speaker2/audio
    outputs: [final_audio]
```

---

## Performance Considerations

- **Transcript parsing**: <100ms for 10K messages
- **AI refinement**: 5-30s depending on LLM (streaming for UX)
- **TTS synthesis**: ~1s per 100 characters (parallel for 2+ speakers)
- **Audio mixing**: <5s for 30min podcast
- **Total pipeline**: ~1-3min for typical chat (500 messages → 30min podcast)

---

## Success Criteria

- [x] Architecture documented
- [x] UI framework implemented
- [x] Shell integration complete
- [x] Build successful
- [x] Transcript parser (3 formats minimum) ✅ Complete
- [ ] AI refinement working
- [ ] Batch TTS synthesis
- [ ] Audio export (MP3)
- [ ] End-to-end test: 100 messages → 5min podcast

---

## Implementation Milestones

### ✅ Milestone 1: UI Framework (2026-01-08)
- Created project structure and dependencies
- Implemented complete UI layout with split-view editor
- Integrated with MoFA Studio shell
- Added sidebar navigation and icon
- Implemented dark mode support
- Build successful with no errors

### ✅ Milestone 2: Transcript Parsing (2026-01-08)
- Implemented `TranscriptParser` trait
- Created 3 parsers: PlainText, JSON, Markdown
- Implemented `ParserFactory` with auto-detection
- Added speaker statistics extraction
- All unit tests passing (5/5)
- ~672 lines of production code

### ✅ Milestone 3: UI Integration (2026-01-08)
- Integrated parser with CastScreen
- Added file import button handler
- Display parsed transcript in original editor
- Show speaker statistics in left panel
- Update file info with message/speaker count
- Created test sample files (plain, JSON, Markdown)
- ~590 lines total in screen.rs

### 🚧 Milestone 4: Core Functionality (Next)
- Add AI script refinement (P0.3)
- Integrate batch TTS synthesis (P0.4)
- Add audio mixing and export (P0.5)

---

**Target Release**: v0.2.0 (Q1 2026)
