//! MoFA Cast Screen - Main UI for chat to podcast transformation

use makepad_widgets::*;
use crate::transcript_parser::{ParserFactory, Transcript};
use crate::script_refiner::{MockRefiner, RefinementConfig, RefinementRequest, ScriptRefiner};
use crate::tts_batch::{BatchTtsSynthesizer, KokoroBackend, ScriptSegmenter, TtsConfig, TtsEngineWrapper, TtsFactory, TtsRequest, TtsResult};
use crate::audio_mixer::{AudioMixer, AudioSegmentInfo, MixerConfig, MixerRequest};
use crate::dora_integration::{DoraIntegration, DoraEvent, DoraState};
use std::sync::{Arc, Mutex};
use std::fs;
use std::collections::HashMap;
use std::path::PathBuf;

live_design! {
    use link::theme::*;
    use link::shaders::*;
    use link::widgets::*;

    use mofa_widgets::theme::*;

    // Local layout constants
    SECTION_SPACING = 12.0
    PANEL_RADIUS = 4.0
    PANEL_PADDING = 12.0

    // Reusable panel header
    PanelHeader = <View> {
        width: Fill, height: Fit
        padding: {left: 16, right: 16, top: 12, bottom: 12}
        align: {y: 0.5}
        show_bg: true
        draw_bg: {
            instance dark_mode: 0.0
            fn pixel(self) -> vec4 {
                return mix((SLATE_50), (SLATE_800), self.dark_mode);
            }
        }
    }

    // MoFA Cast Screen
    pub CastScreen = {{CastScreen}} {
        width: Fill, height: Fill
        flow: Down
        spacing: (SECTION_SPACING)
        padding: { left: 16, right: 16, top: 16, bottom: 16 }
        align: {y: 0.0}
        show_bg: true
        draw_bg: {
            instance dark_mode: 0.0
            fn pixel(self) -> vec4 {
                return mix((DARK_BG), (DARK_BG_DARK), self.dark_mode);
            }
        }

        // Header section
        header = <View> {
            width: Fill, height: Fit
            flow: Right
            spacing: 16
            align: {y: 0.5}

            title_label = <Label> {
                text: "MoFA Cast"
                draw_text: {
                    instance dark_mode: 0.0
                    text_style: <FONT_BOLD>{ font_size: 24.0 }
                    fn get_color(self) -> vec4 {
                        return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                    }
                }
            }

            <Filler> {}

            description = <Label> {
                text: "Transform chat transcripts into podcast audio"
                draw_text: {
                    instance dark_mode: 0.0
                    text_style: <FONT_REGULAR>{ font_size: 13.0 }
                    fn get_color(self) -> vec4 {
                        return mix((TEXT_SECONDARY), (TEXT_SECONDARY_DARK), self.dark_mode);
                    }
                }
            }
        }

        // Main content area with horizontal layout
        main_content = <View> {
            width: Fill, height: Fill
            flow: Right
            spacing: (SECTION_SPACING)

            // Left panel - Import and controls
            left_panel = <View> {
                width: 300, height: Fill
                flow: Down
                spacing: (SECTION_SPACING)

                // Import section
                import_section = <RoundedView> {
                    width: Fill, height: Fit
                    show_bg: true
                    draw_bg: {
                        instance dark_mode: 0.0
                        border_radius: (PANEL_RADIUS)
                        fn pixel(self) -> vec4 {
                            let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                            sdf.box(0., 0., self.rect_size.x, self.rect_size.y, self.border_radius);
                            let bg = mix((PANEL_BG), (PANEL_BG_DARK), self.dark_mode);
                            sdf.fill(bg);
                            return sdf.result;
                        }
                    }
                    flow: Down
                    padding: (PANEL_PADDING)

                    <PanelHeader> {
                        label = <Label> {
                            text: "Import Transcript"
                            draw_text: {
                                instance dark_mode: 0.0
                                text_style: <FONT_SEMIBOLD>{ font_size: 14.0 }
                                fn get_color(self) -> vec4 {
                                    return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                }
                            }
                        }
                    }

                    format_dropdown = <DropDown> {
                        width: Fill
                        labels: ["Auto Detect", "Plain Text", "JSON", "Markdown"]
                        values: [0, 1, 2, 3]
                    }

                    import_button = <Button> {
                        width: Fill
                        text: "Select File"
                        draw_text: {
                            text_style: <FONT_MEDIUM>{ font_size: 13.0 }
                            color: (WHITE)
                        }
                        draw_bg: {
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, 4.0);
                                sdf.fill(#3b82f6);
                                return sdf.result;
                            }
                        }
                    }

                    file_info = <Label> {
                        text: "No file selected"
                        draw_text: {
                            instance dark_mode: 0.0
                            text_style: <FONT_REGULAR>{ font_size: 11.0 }
                            fn get_color(self) -> vec4 {
                                return mix((TEXT_SECONDARY), (TEXT_SECONDARY_DARK), self.dark_mode);
                            }
                        }
                    }
                }

                // Speakers section
                speakers_section = <RoundedView> {
                    width: Fill, height: Fill
                    show_bg: true
                    draw_bg: {
                        instance dark_mode: 0.0
                        border_radius: (PANEL_RADIUS)
                        fn pixel(self) -> vec4 {
                            let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                            sdf.box(0., 0., self.rect_size.x, self.rect_size.y, self.border_radius);
                            let bg = mix((PANEL_BG), (PANEL_BG_DARK), self.dark_mode);
                            sdf.fill(bg);
                            return sdf.result;
                        }
                    }
                    flow: Down
                    padding: (PANEL_PADDING)

                    <PanelHeader> {
                        label = <Label> {
                            text: "Speakers"
                            draw_text: {
                                instance dark_mode: 0.0
                                text_style: <FONT_SEMIBOLD>{ font_size: 14.0 }
                                fn get_color(self) -> vec4 {
                                    return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                }
                            }
                        }
                    }

                    speakers_list = <View> {
                        width: Fill, height: Fit
                        flow: Down
                        spacing: 8

                        placeholder = <Label> {
                            text: "Import a transcript to see speakers"
                            draw_text: {
                                instance dark_mode: 0.0
                                text_style: <FONT_REGULAR>{ font_size: 12.0 }
                                fn get_color(self) -> vec4 {
                                    return mix((TEXT_SECONDARY), (TEXT_SECONDARY_DARK), self.dark_mode);
                                }
                            }
                        }
                    }
                }
            }

            // Right panel - Editor
            right_panel = <View> {
                width: Fill, height: Fill
                flow: Down
                spacing: (SECTION_SPACING)

                // Control buttons
                control_bar = <RoundedView> {
                    width: Fill, height: Fit
                    show_bg: true
                    draw_bg: {
                        instance dark_mode: 0.0
                        border_radius: (PANEL_RADIUS)
                        fn pixel(self) -> vec4 {
                            let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                            sdf.box(0., 0., self.rect_size.x, self.rect_size.y, self.border_radius);
                            let bg = mix((PANEL_BG), (PANEL_BG_DARK), self.dark_mode);
                            sdf.fill(bg);
                            return sdf.result;
                        }
                    }
                    flow: Right
                    padding: {top: 8, bottom: 8, left: 16, right: 16}
                    spacing: 8
                    align: {y: 0.5, x: 0.0}

                    refine_button = <Button> {
                        width: Fit, height: 28
                        margin: {right: 8}
                        text: "✨ Refine Script"
                        draw_text: {
                            text_style: <FONT_MEDIUM>{ font_size: 13.0 }
                            color: (WHITE)
                        }
                        draw_bg: {
                            instance hover: 0.0
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, 4.0);
                                let color = mix(#8b5cf6, #a78bfa, self.hover);
                                sdf.fill(color);
                                return sdf.result;
                            }
                        }
                        animator: {
                            hover = {
                                default: off
                                off = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 0.0}} }
                                on = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 1.0}} }
                            }
                        }
                    }

                    synthesize_button = <Button> {
                        width: Fit, height: 28
                        text: "🎙️ Synthesize Audio"
                        draw_text: {
                            text_style: <FONT_MEDIUM>{ font_size: 13.0 }
                            color: (WHITE)
                        }
                        draw_bg: {
                            instance hover: 0.0
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, 4.0);
                                let color = mix(#10b981, #34d399, self.hover);
                                sdf.fill(color);
                                return sdf.result;
                            }
                        }
                        animator: {
                            hover = {
                                default: off
                                off = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 0.0}} }
                                on = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 1.0}} }
                            }
                        }
                    }

                    export_button = <Button> {
                        width: Fit, height: 28
                        text: "📥 Export Audio"
                        draw_text: {
                            text_style: <FONT_MEDIUM>{ font_size: 13.0 }
                            color: (WHITE)
                        }
                        draw_bg: {
                            instance hover: 0.0
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, 4.0);
                                let color = mix(#f59e0b, #fbbf24, self.hover);
                                sdf.fill(color);
                                return sdf.result;
                            }
                        }
                        animator: {
                            hover = {
                                default: off
                                off = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 0.0}} }
                                on = { from: {all: Forward {duration: 0.1}} apply: {draw_bg: {hover: 1.0}} }
                            }
                        }
                    }

                    <Filler> {}

                    progress_label = <Label> {
                        text: ""
                        draw_text: {
                            instance dark_mode: 0.0
                            text_style: <FONT_REGULAR>{ font_size: 12.0 }
                            fn get_color(self) -> vec4 {
                                return mix((TEXT_SECONDARY), (TEXT_SECONDARY_DARK), self.dark_mode);
                            }
                        }
                    }
                }

                // Editor area with split view
                editor_container = <View> {
                    width: Fill, height: Fill
                    flow: Right
                    spacing: 8

                    // Original transcript
                    original_panel = <RoundedView> {
                        width: Fill, height: Fill
                        show_bg: true
                        draw_bg: {
                            instance dark_mode: 0.0
                            border_radius: (PANEL_RADIUS)
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, self.border_radius);
                                let bg = mix((PANEL_BG), (PANEL_BG_DARK), self.dark_mode);
                                sdf.fill(bg);
                                return sdf.result;
                            }
                        }
                        flow: Down

                        <PanelHeader> {
                            label = <Label> {
                                text: "Original Transcript"
                                draw_text: {
                                    instance dark_mode: 0.0
                                    text_style: <FONT_SEMIBOLD>{ font_size: 13.0 }
                                    fn get_color(self) -> vec4 {
                                        return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                    }
                                }
                            }
                        }

                        original_text = <TextInput> {
                            width: Fill, height: Fill
                            text: "Import a transcript to begin..."
                            draw_bg: {
                                instance dark_mode: 0.0
                                fn pixel(self) -> vec4 {
                                    let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                    sdf.rect(0., 0., self.rect_size.x, self.rect_size.y);
                                    let bg = mix((WHITE), (SLATE_900), self.dark_mode);
                                    sdf.fill(bg);
                                    return sdf.result;
                                }
                            }
                            draw_text: {
                                instance dark_mode: 0.0
                                text_style: <FONT_REGULAR>{ font_size: 12.0 }
                                fn get_color(self) -> vec4 {
                                    return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                }
                            }
                        }
                    }

                    // Refined script
                    refined_panel = <RoundedView> {
                        width: Fill, height: Fill
                        show_bg: true
                        draw_bg: {
                            instance dark_mode: 0.0
                            border_radius: (PANEL_RADIUS)
                            fn pixel(self) -> vec4 {
                                let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                sdf.box(0., 0., self.rect_size.x, self.rect_size.y, self.border_radius);
                                let bg = mix((PANEL_BG), (PANEL_BG_DARK), self.dark_mode);
                                sdf.fill(bg);
                                return sdf.result;
                            }
                        }
                        flow: Down

                        <PanelHeader> {
                            label = <Label> {
                                text: "Refined Script (Editable)"
                                draw_text: {
                                    instance dark_mode: 0.0
                                    text_style: <FONT_SEMIBOLD>{ font_size: 13.0 }
                                    fn get_color(self) -> vec4 {
                                        return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                    }
                                }
                            }
                        }

                        refined_text = <TextInput> {
                            width: Fill, height: Fill
                            text: "Click 'Refine Script' to generate podcast script..."
                            draw_bg: {
                                instance dark_mode: 0.0
                                fn pixel(self) -> vec4 {
                                    let sdf = Sdf2d::viewport(self.pos * self.rect_size);
                                    sdf.rect(0., 0., self.rect_size.x, self.rect_size.y);
                                    let bg = mix((WHITE), (SLATE_900), self.dark_mode);
                                    sdf.fill(bg);
                                    return sdf.result;
                                }
                            }
                            draw_text: {
                                instance dark_mode: 0.0
                                text_style: <FONT_REGULAR>{ font_size: 12.0 }
                                fn get_color(self) -> vec4 {
                                    return mix((TEXT_PRIMARY), (TEXT_PRIMARY_DARK), self.dark_mode);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

#[derive(Live, LiveHook, Widget)]
pub struct CastScreen {
    #[deref]
    view: View,

    #[rust]
    transcript: Option<Transcript>,

    #[rust]
    is_refining: bool,

    #[rust]
    refined_script: Option<String>,

    #[rust]
    is_synthesizing: bool,

    #[rust]
    tts_result: Option<TtsResult>,

    #[rust]
    is_exporting: bool,

    #[rust]
    speaker_colors: Vec<(String, Vec3)>,

    // Dora Integration
    #[rust]
    dora_integration: Option<DoraIntegration>,

    #[rust]
    dora_dataflow_path: Option<PathBuf>,

    #[rust]
    dora_timer: Timer,

    // Audio collection from Dora
    #[rust]
    collected_audio_segments: Vec<crate::audio_mixer::AudioSegmentInfo>,

    #[rust]
    total_segments_expected: usize,

    #[rust]
    segments_received: usize,
}

impl Widget for CastScreen {
    fn handle_event(&mut self, cx: &mut Cx, event: &Event, scope: &mut Scope) {
        self.view.handle_event(cx, event, scope);

        // Handle timer events for Dora polling (must check before Actions match)
        if self.dora_timer.is_event(event).is_some() {
            ::log::trace!("Dora timer triggered - polling events");
            self.poll_dora_events(cx);
        }

        // Handle button clicks
        let actions = match event {
            Event::Actions(actions) => actions.as_slice(),
            _ => return,
        };

        // Import button
        if self.view.button(ids!(main_content.left_panel.import_section.import_button)).clicked(actions) {
            self.handle_file_import(cx);
        }

        // Refine button
        if self.view.button(ids!(main_content.right_panel.control_bar.refine_button)).clicked(actions) {
            self.handle_refine_script(cx);
        }

        // Synthesize button
        if self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button)).clicked(actions) {
            self.handle_synthesize_audio(cx);
        }

        // Export button
        if self.view.button(ids!(main_content.right_panel.control_bar.export_button)).clicked(actions) {
            self.handle_export_audio(cx);
        }
    }

    fn draw_walk(&mut self, cx: &mut Cx2d, scope: &mut Scope, walk: Walk) -> DrawStep {
        self.view.draw_walk(cx, scope, walk)
    }
}

// Helper methods for CastScreen
impl CastScreen {
    /// Handle file import button click
    fn handle_file_import(&mut self, cx: &mut Cx) {
        // Use rfd to open file dialog
        // Note: On macOS, file dialogs must run on main thread
        // We need to handle this carefully to avoid blocking UI

        ::log::info!("Opening file dialog...");

        // Try to open file dialog
        let file_handle = rfd::FileDialog::new()
            .add_filter("Text Files", &["txt", "json", "md"])
            .add_filter("All Files", &["*"])
            .set_title("Select Transcript File")
            .pick_file();

        match file_handle {
            Some(file_path) => {
                ::log::info!("File selected: {:?}", file_path);

                // Read file content
                match fs::read_to_string(&file_path) {
                    Ok(content) => {
                        ::log::info!("File read successfully: {} bytes", content.len());

                        // Create parser factory and parse the transcript
                        let parser_factory = ParserFactory::new();

                        match parser_factory.parse_auto(&content) {
                            Ok(transcript) => {
                                ::log::info!("Transcript parsed successfully: {} speakers, {} messages",
                                    transcript.metadata.participants.len(),
                                    transcript.message_count());

                                // Store the transcript
                                self.transcript = Some(transcript.clone());

                                // Update UI with parsed content
                                let path_str = file_path.to_string_lossy().to_string();
                                self.update_ui_with_transcript(cx, &transcript, &path_str);

                                // Clear previous refined script and TTS result
                                self.refined_script = None;
                                self.tts_result = None;

                                // Clear refined text editor
                                self.view.text_input(ids!(main_content.right_panel.editor_container.refined_text))
                                    .set_text(cx, "Click 'Refine Script' to generate podcast script...");

                                // Clear progress label
                                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                                    .set_text(cx, "");
                            }
                            Err(e) => {
                                ::log::error!("Failed to parse transcript: {}", e);
                                // Show error message in UI
                                let error_msg = format!("Parse error: {}", e);
                                self.view.label(ids!(main_content.left_panel.import_section.file_info))
                                    .set_text(cx, &error_msg);

                                eprintln!("Failed to parse transcript: {}", e);
                            }
                        }
                    }
                    Err(e) => {
                        ::log::error!("Failed to read file: {}", e);
                        // Show error message
                        let error_msg = format!("Error reading file: {}", e);
                        self.view.label(ids!(main_content.left_panel.import_section.file_info))
                            .set_text(cx, &error_msg);

                        eprintln!("Failed to read file: {}", e);
                    }
                }
            }
            None => {
                ::log::info!("File dialog cancelled by user");
                // User cancelled the dialog
                self.view.label(ids!(main_content.left_panel.import_section.file_info))
                    .set_text(cx, "No file selected");
            }
        }

        self.view.redraw(cx);
    }

    /// Update UI elements with parsed transcript data
    fn update_ui_with_transcript(&mut self, cx: &mut Cx, transcript: &Transcript, file_path: &str) {
        // Update file info label
        let file_name = std::path::Path::new(file_path)
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("Unknown file");

        let info_text = format!(
            "{}\n{} messages • {} speakers",
            file_name,
            transcript.message_count(),
            transcript.metadata.participants.len()
        );

        self.view.label(ids!(main_content.left_panel.import_section.file_info))
            .set_text(cx, &info_text);

        // Generate colors for speakers
        self.generate_speaker_colors(transcript);

        // Format original transcript for display
        let original_text = self.format_transcript_for_display(transcript);
        self.view.text_input(ids!(main_content.right_panel.editor_container.original_text))
            .set_text(cx, &original_text);

        // Update speakers list
        self.update_speakers_list(cx, transcript);

        // Redraw the UI
        self.view.redraw(cx);
    }

    /// Generate colors for each speaker
    fn generate_speaker_colors(&mut self, transcript: &Transcript) {
        self.speaker_colors.clear();

        let speakers = transcript.get_speakers();
        let predefined_colors = vec![
            Vec3 { x: 0.24, y: 0.51, z: 0.96 },  // Blue #3b82f6
            Vec3 { x: 0.06, y: 0.73, z: 0.50 },  // Green #10b981
            Vec3 { x: 0.98, y: 0.38, z: 0.26 },  // Red #f97316
            Vec3 { x: 0.55, y: 0.36, z: 0.96 },  // Purple #8b5cf6
            Vec3 { x: 0.93, y: 0.27, z: 0.51 },  // Pink #ef4444
            Vec3 { x: 0.96, y: 0.62, z: 0.07 },  // Orange #f59e0b
            Vec3 { x: 0.14, y: 0.73, z: 0.73 },  // Teal #0d9488
            Vec3 { x: 0.72, y: 0.11, z: 0.65 },  // Magenta #b81d7d
        ];

        for (i, speaker) in speakers.iter().enumerate() {
            let color = predefined_colors.get(i % predefined_colors.len()).copied().unwrap();
            self.speaker_colors.push((speaker.name.clone(), color));
        }
    }

    /// Format transcript as human-readable text
    fn format_transcript_for_display(&self, transcript: &Transcript) -> String {
        let mut text = String::new();

        for msg in &transcript.messages {
            text.push_str(&format!("{}: {}\n", msg.speaker, msg.text));
        }

        text
    }

    /// Update the speakers list in the left panel
    fn update_speakers_list(&mut self, cx: &mut Cx, transcript: &Transcript) {
        let speakers = transcript.get_speakers();

        if speakers.is_empty() {
            // Show placeholder
            self.view.label(ids!(main_content.left_panel.speakers_section.speakers_list.placeholder))
                .set_text(cx, "No speakers found");
        } else {
            // For now, just update the placeholder with summary
            // TODO: Implement dynamic speaker list widget
            let summary = speakers.iter()
                .map(|s| format!("{} ({} msgs)", s.name, s.message_count))
                .collect::<Vec<_>>()
                .join("\n");

            self.view.label(ids!(main_content.left_panel.speakers_section.speakers_list.placeholder))
                .set_text(cx, &summary);
        }
    }

    /// Handle script refinement
    fn handle_refine_script(&mut self, cx: &mut Cx) {
        // Check if transcript is loaded
        let transcript = match &self.transcript {
            Some(t) => t.clone(),
            None => {
                // Show error message
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, "⚠️ Please import a transcript first");
                self.view.redraw(cx);
                return;
            }
        };

        // Show loading state
        self.is_refining = true;
        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
            .set_text(cx, "✨ Refining script...");
        self.view.button(ids!(main_content.right_panel.control_bar.refine_button))
            .set_enabled(cx, false);
        self.view.redraw(cx);

        // Use mock refiner for now (synchronous for simplicity)
        // In production, you'd spawn an async task
        let refiner = MockRefiner;
        let config = RefinementConfig::default();
        let request = RefinementRequest { transcript, config };

        // Create a runtime for the async operation
        let rt = match tokio::runtime::Runtime::new() {
            Ok(rt) => rt,
            Err(e) => {
                let error_msg = format!("❌ Runtime error: {}", e);
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                self.is_refining = false;
                self.view.button(ids!(main_content.right_panel.control_bar.refine_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }
        };

        // Execute refinement
        match rt.block_on(refiner.refine(request)) {
            Ok(result) => {
                // Store refined script
                self.refined_script = Some(result.refined_script.clone());

                // Update UI with refined script
                self.view.text_input(ids!(main_content.right_panel.editor_container.refined_text))
                    .set_text(cx, &result.refined_script);

                // Update progress label
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &format!("✅ Done! {} chars • {}ms",
                        result.refined_script.len(),
                        result.duration_ms));
            }
            Err(e) => {
                // Show error with more details
                let error_msg = format!("❌ Refinement failed: {}", e);
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                eprintln!("Script refinement error: {:?}", e);
            }
        }

        self.is_refining = false;
        self.view.button(ids!(main_content.right_panel.control_bar.refine_button))
            .set_enabled(cx, true);
        self.view.redraw(cx);
    }

    /// Initialize default values for rust fields
    fn ensure_defaults(&mut self) {
        // Initialize TTS engine configuration
        // Set environment variable to use Kokoro: MOFA_CAST_TTS=kokoro
        // Otherwise defaults to Mock for testing
    }

    /// Write audio samples to WAV file
    fn write_wav_file(&self, path: &std::path::Path, samples: &[i16], sample_rate: u32, channels: u16) -> Result<(), String> {
        use std::io::Write;

        // Create file
        let mut file = std::fs::File::create(path)
            .map_err(|e| format!("Failed to create file: {}", e))?;

        // WAV header parameters
        let byte_rate = sample_rate * channels as u32 * 2;
        let block_align = channels * 2;
        let data_size = samples.len() * 2;
        let file_size = 36 + data_size as u32;

        // Write RIFF header
        file.write_all(b"RIFF").map_err(|e| format!("Failed to write RIFF: {}", e))?;
        file.write_all(&file_size.to_le_bytes()).map_err(|e| format!("Failed to write file size: {}", e))?;
        file.write_all(b"WAVE").map_err(|e| format!("Failed to write WAVE: {}", e))?;

        // Write fmt chunk
        file.write_all(b"fmt ").map_err(|e| format!("Failed to write fmt: {}", e))?;
        file.write_all(&16u32.to_le_bytes()).map_err(|e| format!("Failed to write fmt size: {}", e))?; // PCM chunk size
        file.write_all(&1u16.to_le_bytes()).map_err(|e| format!("Failed to write audio format: {}", e))?; // Audio format (PCM)
        file.write_all(&channels.to_le_bytes()).map_err(|e| format!("Failed to write channels: {}", e))?;
        file.write_all(&sample_rate.to_le_bytes()).map_err(|e| format!("Failed to write sample rate: {}", e))?;
        file.write_all(&byte_rate.to_le_bytes()).map_err(|e| format!("Failed to write byte rate: {}", e))?;
        file.write_all(&block_align.to_le_bytes()).map_err(|e| format!("Failed to write block align: {}", e))?;
        file.write_all(&16u16.to_le_bytes()).map_err(|e| format!("Failed to write bits per sample: {}", e))?; // Bits per sample

        // Write data chunk
        file.write_all(b"data").map_err(|e| format!("Failed to write data: {}", e))?;
        file.write_all(&(data_size as u32).to_le_bytes()).map_err(|e| format!("Failed to write data size: {}", e))?;

        // Write sample data
        for sample in samples {
            file.write_all(&sample.to_le_bytes()).map_err(|e| format!("Failed to write sample: {}", e))?;
        }

        Ok(())
    }

    /// Create TTS engine based on current configuration
    fn create_tts_engine(&self) -> Result<TtsEngineWrapper, String> {
        // Check environment variable for engine selection
        let tts_engine = std::env::var("MOFA_CAST_TTS").unwrap_or_default();

        match tts_engine.as_str() {
            "kokoro" => {
                ::log::info!("Using Dora Kokoro TTS engine (local, real TTS)");
                let engine = TtsFactory::create_dora_kokoro_engine()
                    .with_backend(KokoroBackend::Auto)
                    .with_language("en")
                    .with_voice("af_heart")
                    .with_speed(1.0);
                Ok(TtsEngineWrapper::Kokoro(engine))
            }
            "mock" | "" | _ => {
                ::log::info!("Using Mock TTS engine (test tones only)");
                ::log::info!("To use real TTS, set environment variable: MOFA_CAST_TTS=kokoro");
                Ok(TtsEngineWrapper::Mock(TtsFactory::create_mock_engine()))
            }
        }
    }

    /// Handle TTS synthesis using Dora dataflow
    fn handle_synthesize_audio(&mut self, cx: &mut Cx) {
        // Check if refined script is available
        let refined_script = match &self.refined_script {
            Some(script) => script.clone(),
            None => {
                // Show error message
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, "⚠️ Please refine script first");
                self.view.redraw(cx);
                return;
            }
        };

        // Show loading state
        self.is_synthesizing = true;
        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
            .set_text(cx, "🎙️ Starting Dora dataflow...");
        self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
            .set_enabled(cx, false);
        self.view.button(ids!(main_content.right_panel.control_bar.export_button))
            .set_enabled(cx, false);
        self.view.redraw(cx);

        // Initialize Dora integration
        self.init_dora(cx);

        // Create segmenter and parse script
        let segmenter = match ScriptSegmenter::new() {
            Ok(s) => s,
            Err(e) => {
                let error_msg = format!("❌ Segmenter error: {}", e);
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Script segmentation error: {:?}", e);
                self.is_synthesizing = false;
                self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }
        };

        let segments = match segmenter.segment_script(&refined_script) {
            Ok(segments) => segments,
            Err(e) => {
                let error_msg = format!("❌ Segmentation error: {}", e);
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Script segmentation error: {:?}", e);
                self.is_synthesizing = false;
                self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }
        };

        // Initialize audio collection state
        self.total_segments_expected = segments.len();
        self.segments_received = 0;
        self.collected_audio_segments.clear();

        ::log::info!("Expecting {} audio segments from Dora dataflow", self.total_segments_expected);

        // Get speakers list for voice mapping
        let speakers: Vec<String> = segments.iter().map(|s| s.speaker.clone()).collect();
        let voice_mapping = crate::dora_integration::VoiceMapping::from_speakers(&speakers);

        // Log the voice mapping
        ::log::info!("Voice mapping for {} speakers:", voice_mapping.voices.len());
        for voice_config in &voice_mapping.voices {
            ::log::info!("  '{}' → '{}' (speed: {:.1})",
                       voice_config.speaker, voice_config.voice_name, voice_config.speed);
        }

        // Convert to Dora script segments with voice information
        let default_voice = crate::dora_integration::VoiceConfig::new("unknown", "Luo Xiang", 1.0);
        let dora_segments: Vec<crate::dora_integration::ScriptSegment> = segments
            .iter()
            .enumerate()
            .map(|(idx, seg)| {
                // Normalize speaker names (merge [主持人] and host into one)
                let normalized_speaker = self.normalize_speaker_name(&seg.speaker);

                // Get voice config for normalized speaker
                let voice_config = voice_mapping.get_voice_for_speaker(&normalized_speaker)
                    .unwrap_or(&default_voice);

                crate::dora_integration::ScriptSegment {
                    speaker: normalized_speaker,
                    text: seg.text.clone(),
                    segment_index: idx,
                    voice_name: voice_config.voice_name.clone(),
                    speed: voice_config.speed,
                }
            })
            .collect();

        // Save segment count before moving dora_segments
        let segment_count = dora_segments.len();

        // Get dataflow path
        let dataflow_path = match &self.dora_dataflow_path {
            Some(path) => path.clone(),
            None => {
                let error_msg = "❌ Dataflow configuration not found".to_string();
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Dataflow path not set");
                self.is_synthesizing = false;
                self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }
        };

        // Start Dora dataflow with configuration
        if let Some(ref dora) = self.dora_integration {
            // Set voice mapping before starting dataflow
            if !dora.set_voice_mapping(voice_mapping) {
                ::log::warn!("Failed to set voice mapping (non-critical)");
            }

            if !dora.start_dataflow(dataflow_path.clone()) {
                let error_msg = "❌ Failed to start dataflow".to_string();
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Failed to start dataflow");
                self.is_synthesizing = false;
                self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }

            // Send script segments for synthesis
            if !dora.send_script_segments(dora_segments) {
                let error_msg = "❌ Failed to send script segments".to_string();
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Failed to send script segments");
                self.is_synthesizing = false;
                self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                    .set_enabled(cx, true);
                self.view.redraw(cx);
                return;
            }

            ::log::info!("Started Dora TTS synthesis with {} segments", segment_count);
            self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                .set_text(cx, &format!("🎙️ Synthesizing {} segments via Dora...", segment_count));
            self.view.redraw(cx);
        } else {
            let error_msg = "❌ Dora integration not available".to_string();
            self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                .set_text(cx, &error_msg);
            ::log::error!("Dora integration is None");
            self.is_synthesizing = false;
            self.view.button(ids!(main_content.right_panel.control_bar.synthesize_button))
                .set_enabled(cx, true);
            self.view.redraw(cx);
        }
    }

    /// Handle audio export
    fn handle_export_audio(&mut self, cx: &mut Cx) {
        // Check if we have collected audio segments from Dora
        if self.collected_audio_segments.is_empty() {
            // Show error message
            self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                .set_text(cx, "⚠️ No audio segments collected. Please synthesize audio first");
            self.view.redraw(cx);
            return;
        }

        // Show loading state
        self.is_exporting = true;
        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
            .set_text(cx, "📥 Mixing and exporting audio...");
        self.view.button(ids!(main_content.right_panel.control_bar.export_button))
            .set_enabled(cx, false);
        self.view.redraw(cx);

        ::log::info!("Exporting {} audio segments", self.collected_audio_segments.len());

        // Get sample rate from first segment (PrimeSpeech uses 32000Hz)
        let first_sample_rate = self.collected_audio_segments.first()
            .map(|s| s.sample_rate)
            .unwrap_or(32000);  // Default to PrimeSpeech rate

        let first_channels = self.collected_audio_segments.first()
            .map(|s| s.channels)
            .unwrap_or(1);  // Default to mono

        ::log::info!("Using sample rate: {}Hz, channels: {}", first_sample_rate, first_channels);

        // Create mixer config with detected sample rate
        let output_dir = std::path::PathBuf::from("./output/mofa-cast");
        let config = MixerConfig {
            output_path: output_dir.join("podcast"),
            silence_duration_secs: 0.5,
            sample_rate: first_sample_rate,  // Use detected sample rate
            channels: first_channels,         // Use detected channels
            ..Default::default()
        };

        let request = MixerRequest {
            segments: self.collected_audio_segments.clone(),
            config,
        };

        // Create mixer and mix
        let mixer = AudioMixer::new();
        match mixer.mix(request) {
            Ok(result) => {
                // Update progress label with success message
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &format!(
                        "✅ Exported! {:.1}s audio • {}KB",
                        result.total_duration_secs,
                        result.file_size_bytes / 1024
                    ));

                // Log success message with file location
                ::log::info!("Audio exported successfully: {:.1}s, {}KB",
                    result.total_duration_secs, result.file_size_bytes / 1024);

                // Try to find and log the actual file path
                let podcast_wav = output_dir.join("podcast.wav");
                if podcast_wav.exists() {
                    ::log::info!("Export file: {}", podcast_wav.display());
                }
            }
            Err(e) => {
                // Show error
                let error_msg = format!("❌ Export failed: {}", e);
                self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                    .set_text(cx, &error_msg);
                ::log::error!("Audio export error: {:?}", e);
            }
        }

        self.is_exporting = false;
        self.view.button(ids!(main_content.right_panel.control_bar.export_button))
            .set_enabled(cx, true);
        self.view.redraw(cx);
    }

    /// Normalize speaker names to merge duplicates
    /// Maps various speaker name variants to unified names
    /// Examples: "[主持人]" -> "host", "Host" -> "host", etc.
    fn normalize_speaker_name(&self, speaker: &str) -> String {
        match speaker {
            // Chinese主持人 variants -> host
            s if s.contains("主持人") => "host".to_string(),
            s if s.contains("主持") => "host".to_string(),

            // Case-insensitive host mapping
            "Host" | "HOST" => "host".to_string(),

            // Case-insensitive guest mappings
            "Guest1" | "GUEST1" => "guest1".to_string(),
            "Guest2" | "GUEST2" => "guest2".to_string(),
            "Guest" | "GUEST" => "guest1".to_string(), // Default to guest1

            // Remove brackets and special characters
            s if s.starts_with('[') && s.ends_with(']') => {
                s[1..s.len()-1].to_string()
            }

            // Return as-is if no mapping found
            _ => speaker.to_string(),
        }
    }
}

// =====================================================
// DORA INTEGRATION METHODS (for CastScreen)
// =====================================================

impl CastScreen {
    /// Initialize Dora integration (lazy initialization)
    fn init_dora(&mut self, cx: &mut Cx) {
        if self.dora_integration.is_some() {
            return;
        }

        ::log::info!("Initializing Dora integration for mofa-cast");
        let integration = DoraIntegration::new();
        self.dora_integration = Some(integration);

        // Start timer to poll for Dora events (100ms interval)
        self.dora_timer = cx.start_interval(0.1);

        // Find default dataflow
        let cwd = std::env::current_dir().ok();
        let dataflow_path = cwd.and_then(|p| {
            // First try: Multi-voice batch TTS (P1.1 feature - 3 voices)
            let multi_voice_path = p.join("apps").join("mofa-cast").join("dataflow").join("multi-voice-batch-tts.yml");
            if multi_voice_path.exists() {
                ::log::info!("Using multi-voice-batch-tts.yml configuration (3 voices: Luo Xiang, Yang Mi, Ma Yun)");
                Some(multi_voice_path)
            } else {
                // Fallback: Single voice config
                let simple_path = p.join("apps").join("mofa-cast").join("dataflow").join("test-primespeech-simple.yml");
                if simple_path.exists() {
                    ::log::info!("Using test-primespeech-simple.yml configuration (single voice: Luo Xiang)");
                    Some(simple_path)
                } else {
                    // Fallback to test-direct config
                    let test_path = p.join("apps").join("mofa-cast").join("dataflow").join("test-direct.yml");
                    if test_path.exists() {
                        ::log::info!("Using test-direct.yml configuration (with text-segmenter)");
                        Some(test_path)
                    } else {
                        // Fallback to batch-tts config
                        let batch_path = p.join("apps").join("mofa-cast").join("dataflow").join("batch-tts.yml");
                        if batch_path.exists() {
                            ::log::info!("Using batch-tts.yml configuration (with text-segmenter)");
                            Some(batch_path)
                        } else {
                            None
                        }
                    }
                }
            }
        });

        self.dora_dataflow_path = dataflow_path;

        ::log::info!("Dora integration initialized, dataflow: {:?}", self.dora_dataflow_path);
    }

    /// Start TTS dataflow
    fn start_tts_dataflow(&mut self, cx: &mut Cx) {
        self.init_dora(cx);

        if let Some(dataflow_path) = &self.dora_dataflow_path {
            if let Some(ref dora) = self.dora_integration {
                ::log::info!("Starting TTS dataflow: {:?}", dataflow_path);
                if dora.start_dataflow(dataflow_path.clone()) {
                    ::log::info!("TTS dataflow started successfully");
                } else {
                    ::log::error!("Failed to start TTS dataflow");
                    // Show error in UI
                    self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                        .set_text(cx, "❌ Failed to start TTS dataflow");
                }
            }
        } else {
            ::log::error!("No dataflow path found");
            self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                .set_text(cx, "❌ Dataflow configuration not found");
        }
    }

    /// Stop TTS dataflow
    fn stop_tts_dataflow(&mut self, cx: &mut Cx) {
        if let Some(ref dora) = self.dora_integration {
            ::log::info!("Stopping TTS dataflow");
            dora.stop_dataflow();
        }
    }

    /// Poll for Dora events
    fn poll_dora_events(&mut self, cx: &mut Cx) {
        if let Some(ref dora) = self.dora_integration {
            let events = dora.poll_events();

            ::log::debug!("Poll dora events: got {} events", events.len());

            for event in events {
                match event {
                    DoraEvent::DataflowStarted { dataflow_id } => {
                        ::log::info!("Dora dataflow started: {}", dataflow_id);
                        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                            .set_text(cx, &format!("✅ Dataflow started: {}", dataflow_id));
                    }
                    DoraEvent::DataflowStopped => {
                        ::log::info!("Dora dataflow stopped");
                        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                            .set_text(cx, "Dataflow stopped");
                    }
                    DoraEvent::AudioSegment { data } => {
                        ::log::info!("Received audio segment in UI: {} samples, rate: {}, channels: {}",
                            data.samples.len(), data.sample_rate, data.channels);

                        // Create output directory if it doesn't exist
                        let output_dir = std::path::PathBuf::from("./output/mofa-cast/dora");
                        if let Err(e) = std::fs::create_dir_all(&output_dir) {
                            ::log::error!("Failed to create output directory: {}", e);
                            let _ = self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                                .set_text(cx, &format!("❌ Failed to create output directory: {}", e));
                            continue;
                        }

                        // Generate filename for this segment
                        let speaker = data.participant_id.as_deref().unwrap_or("unknown");
                        let filename = format!("segment_{:03}_{}.wav", self.segments_received, speaker);
                        let file_path = output_dir.join(&filename);

                        // Convert f32 samples to i16 for WAV format
                        let samples_i16: Vec<i16> = data.samples.iter()
                            .map(|s| (s.clamp(-1.0, 1.0) * 32767.0) as i16)
                            .collect();

                        // Create WAV file
                        if let Err(e) = self.write_wav_file(&file_path, &samples_i16, data.sample_rate, data.channels) {
                            ::log::error!("Failed to write WAV file: {}", e);
                            let _ = self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                                .set_text(cx, &format!("❌ Failed to write audio: {}", e));
                            continue;
                        }

                        // Calculate duration
                        let duration_secs = data.samples.len() as f64 / data.sample_rate as f64;

                        // Create segment info
                        let segment_info = crate::audio_mixer::AudioSegmentInfo {
                            path: file_path,
                            speaker: speaker.to_string(),
                            duration_secs,
                            sample_rate: data.sample_rate,
                            channels: data.channels,
                        };

                        self.collected_audio_segments.push(segment_info);
                        self.segments_received += 1;

                        ::log::info!("✅ Saved segment {} of {}: {} ({:.2}s)",
                            self.segments_received, self.total_segments_expected, filename, duration_secs);

                        // Update progress
                        let pct = if self.total_segments_expected > 0 {
                            (self.segments_received as f32 / self.total_segments_expected as f32 * 100.0) as u32
                        } else {
                            0
                        };

                        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                            .set_text(cx, &format!("🎙️ Received {}/{} segments ({}%) - {}",
                                self.segments_received, self.total_segments_expected, pct, speaker));

                        // Check if all segments received
                        if self.segments_received >= self.total_segments_expected && self.total_segments_expected > 0 {
                            ::log::info!("All {} segments received, enabling export", self.segments_received);
                            self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                                .set_text(cx, &format!("✅ All {} segments received! Ready to export.", self.segments_received));
                            self.view.button(ids!(main_content.right_panel.control_bar.export_button))
                                .set_enabled(cx, true);
                            self.is_synthesizing = false;
                            self.view.redraw(cx);
                        }
                    }
                    DoraEvent::Progress { current, total, speaker } => {
                        let pct = (current as f32 / total as f32 * 100.0) as u32;
                        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                            .set_text(cx, &format!("🎙️ Synthesizing... {}/{} ({}%) - {}", current, total, pct, speaker));
                    }
                    DoraEvent::Error { message } => {
                        ::log::error!("Dora error: {}", message);
                        self.view.label(ids!(main_content.right_panel.control_bar.progress_label))
                            .set_text(cx, &format!("❌ Error: {}", message));
                    }
                    DoraEvent::Log { message } => {
                        ::log::info!("[Dora] {}", message);
                    }
                }
            }
        }
    }
}

// Export WidgetRefExt trait for timer control
impl CastScreenRef {
    /// Update dark mode for this screen
    pub fn update_dark_mode(&self, cx: &mut Cx, dark_mode: f64) {
        if let Some(mut inner) = self.borrow_mut() {
            // Update main background
            inner.view.apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            // Update headers
            inner.view.label(ids!(header.title_label)).apply_over(cx, live!{
                draw_text: { dark_mode: (dark_mode) }
            });

            inner.view.label(ids!(header.description)).apply_over(cx, live!{
                draw_text: { dark_mode: (dark_mode) }
            });

            // Update panels
            inner.view.view(ids!(main_content.left_panel.import_section)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            inner.view.view(ids!(main_content.left_panel.speakers_section)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            inner.view.view(ids!(main_content.right_panel.control_bar)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            inner.view.view(ids!(main_content.right_panel.editor_container.original_panel)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            inner.view.view(ids!(main_content.right_panel.editor_container.refined_panel)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
            });

            // Update text inputs
            inner.view.text_input(ids!(main_content.right_panel.editor_container.original_text)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
                draw_text: { dark_mode: (dark_mode) }
            });

            inner.view.text_input(ids!(main_content.right_panel.editor_container.refined_text)).apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
                draw_text: { dark_mode: (dark_mode) }
            });

            // Update all labels
            inner.view.apply_over(cx, live!{
                draw_bg: { dark_mode: (dark_mode) }
                draw_text: { dark_mode: (dark_mode) }
            });

            inner.view.redraw(cx);
        }
    }
}
